runtime per image [s] : 0.06394328400492669
CPU [1] / GPU [0] : 1
Extra Data [1] / No Extra Data [0] : 0
Other description : Solution based on PIPAL of Gu et al. ECCV 2020. We have a PyTorch implementation,
and report single core CPU runtime. The method was trained on PIPAL dataset
